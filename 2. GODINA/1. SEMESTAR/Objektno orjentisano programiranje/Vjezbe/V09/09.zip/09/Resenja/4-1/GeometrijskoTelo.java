package z11;



public abstract class GeometrijskoTelo {
	
	public abstract double getZapremina();
	public abstract double getPovrsina();

}
