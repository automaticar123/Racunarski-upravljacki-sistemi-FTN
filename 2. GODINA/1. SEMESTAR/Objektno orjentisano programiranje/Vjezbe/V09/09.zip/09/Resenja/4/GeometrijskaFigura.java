package z1;

public abstract class GeometrijskaFigura {
	public abstract double getObim();
	public abstract double getPovrsina();
}
