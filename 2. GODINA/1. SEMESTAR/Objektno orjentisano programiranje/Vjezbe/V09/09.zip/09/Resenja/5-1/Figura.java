package z31;

public interface Figura {
	
	public double getObim();
	public double getPovrsina();

}
