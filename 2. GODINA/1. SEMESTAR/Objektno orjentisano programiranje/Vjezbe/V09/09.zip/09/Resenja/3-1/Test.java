package z4;

public class Test {

	public static void main(String[] args) {
		PP3Prizma p = new PP3Prizma(2, 4);
		System.out.println("Povrsina prizme je: " + p.getP());
		System.out.println("Zapremina prizme je: " + p.getV());
	}

}
