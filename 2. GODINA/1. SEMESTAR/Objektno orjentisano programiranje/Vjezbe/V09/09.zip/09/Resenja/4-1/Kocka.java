package z11;

public class Kocka extends Kvadar {

	public Kocka(double a) {
		super(a, a, a);
	}
	
}
