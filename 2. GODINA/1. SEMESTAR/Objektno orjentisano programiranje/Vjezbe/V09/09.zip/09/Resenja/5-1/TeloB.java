package z31;

public class TeloB extends TeloA {

	public TeloB(double a) {
		super(a, a, a, a, a);
	}

}
